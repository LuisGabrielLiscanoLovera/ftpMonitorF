import sys 
import subprocess
subprocess.call("cmd /c AccesoRunmvl.vbs") # works
#subprocess.call([sys.executable, 'AccesoRunmvl.vbs']) 

